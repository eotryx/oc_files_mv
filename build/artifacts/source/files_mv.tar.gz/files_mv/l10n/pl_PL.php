<?php $TRANSLATIONS = array(
"Destination directory"=>"Katalog docelowy",
"Move"=>"Przenieś",
"Copy"=>"Kopiuj",
);
