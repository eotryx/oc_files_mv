<?php $TRANSLATIONS = array(
"Destination directory"=>"Directorio destino",
"Move"=>"Mover",
"Copy"=>"Copiar",
);
