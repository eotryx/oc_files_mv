<?php $TRANSLATIONS = array(
"Destination directory"=>"R&eacute;pertoire de destination",
"Move"=>"D&eacute;placer",
"Copy"=>"Copier",
);
