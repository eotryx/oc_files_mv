<?php $TRANSLATIONS = array(
"Destination directory"=>"Цільовий каталог",
"Move"=>"Перемістити",
"Copy"=>"Копіювати",
);
