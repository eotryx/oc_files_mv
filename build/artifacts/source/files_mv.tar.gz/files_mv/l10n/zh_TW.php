<?php $TRANSLATIONS = array(
"Destination directory"=>"目標目錄",
"Move"=>"移動",
"Copy"=>"複製",
);
