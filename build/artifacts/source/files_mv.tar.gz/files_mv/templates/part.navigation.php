<ul>
	<li><a href="#">First level entry</a></li>
	<li>
		<a href="#">First level container</a>
		<ul>
			<li><a href="#">Second level entry</a></li>
			<li><a href="#">Second level entry</a></li>
		</ul>
	</li>
</ul>