<?php $TRANSLATIONS = array(
"Destination directory"=>"Zielverzeichnis",
"Move"=>"Verschieben",
"Copy"=>"Kopieren",
);
