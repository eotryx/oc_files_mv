<?php $TRANSLATIONS = array(
"Destination directory"=>"Destino",
"Move"=>"Mover",
"Copy"=>"Copiar",
);
