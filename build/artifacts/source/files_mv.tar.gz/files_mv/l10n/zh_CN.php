<?php $TRANSLATIONS = array(
"Destination directory"=>"目标目录",
"Move"=>"移动",
"Copy"=>"复制",
);
