<?php $TRANSLATIONS = array(
"Destination directory"=>"Целевой каталог",
"Move"=>"Переместить",
"Copy"=>"Скопировать",
);
