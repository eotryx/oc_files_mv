<?php $TRANSLATIONS = array(
"Destination directory"=>"Cílový adresář",
"Move"=>"Přesunout",
"Copy"=>"Kopírovat",
);
